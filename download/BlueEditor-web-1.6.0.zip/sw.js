// Service worker: cache offline do app (só ativo quando servido via http/https).
const C = 'blue-editor-v1';
self.addEventListener('install', e => { self.skipWaiting(); e.waitUntil(caches.open(C).then(c => c.addAll(['./', './index.html', './icon.svg', './manifest.webmanifest']).catch(() => {}))); });
self.addEventListener('activate', e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== C).map(k => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url); if (e.request.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(caches.match(e.request).then(r => { const net = fetch(e.request).then(res => { if (res.ok) caches.open(C).then(c => c.put(e.request, res.clone())); return res; }).catch(() => r); return r || net; }));
});
