const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-D7JjHxZt.js","./index-D1A_7mZ2.js","./index-D4u4IpdA.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-D1A_7mZ2.js";const o=r("App",{web:()=>p(()=>import("./web-D7JjHxZt.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
