const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-YvpZaS5F.js","./index-D1A_7mZ2.js","./index-D4u4IpdA.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-D1A_7mZ2.js";const _=r("Share",{web:()=>t(()=>import("./web-YvpZaS5F.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.ShareWeb)});export{_ as Share};
