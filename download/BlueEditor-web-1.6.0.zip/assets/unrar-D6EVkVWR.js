const r=""+new URL("unrar-De7VYsPt.wasm",import.meta.url).href;export{r as default};
